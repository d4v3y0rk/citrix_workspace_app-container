#!/bin/bash

sysctl kernel.core_uses_pid=1
IFS='
'
userlist=`who`
#declare -i j=0
for i in $userlist
	do
		IFS=' '
		k=($i)
		#echo "$j ---> ${k[1]}"
		if [ "${k[1]}" == "tty7" -o "${k[1]}" == ":0" ] 
			then
				echo "user logged in on tty7 = ${k[0]}" >> /tmp/nsgcepa.txt
                date >>  /tmp/nsgcepa.txt
                chmod 777 /tmp/nsgcepa.txt
				#echo "startnsgclient.sh ${k[0]}" >> nsgclient.misc
				machine=`lsb_release -d`
				if [ -f /tmp/cookiefile ] ; then
					if [[ $machine == *SUSE* ]] ; then
						if [ -f /tmp/nsgdisp ] ; then
							. /tmp/nsgdisp || true
							su - ${k[0]} -c "XAUTHLOCALHOSTNAME=$XAUTHLOCALHOSTNAME XAUTHORITY=$XAUTHORITY DISPLAY=$DISPLAY /opt/Citrix/Browser-EPA/nsgcepa >>  /tmp/nsgcepa.txt 2>&1 &"
						else
							echo "suse machine"
							filename=`ls /var/run/gdm | grep -i ${k[0]}`
							echo $filename
							for dd in $filename
							do
								echo "-->"
								echo $dd
								echo "<--"
								if [ -f /var/run/gdm/$dd/database ] ; then
									su - ${k[0]} -c "XAUTHLOCALHOSTNAME=localhost XAUTHORITY=/var/run/gdm/$dd/database DISPLAY=:0.0 /opt/Citrix/Browser-EPA/nsgcepa >> /tmp/nsgcepa.txt 2>&1 &"
								fi
							done
						fi
					else
						su - ${k[0]} -c "DISPLAY=:0 /opt/Citrix/Browser-EPA/nsgcepa  >> /tmp/nsgcepa.txt 2>&1 &"
					fi
				else
					if [[ $machine == *SUSE* ]] ; then
						if [ -f /tmp/nsgdisp ] ; then
							. /tmp/nsgdisp || true
							su - ${k[0]} -c "XAUTHLOCALHOSTNAME=$XAUTHLOCALHOSTNAME XAUTHORITY=$XAUTHORITY DISPLAY=$DISPLAY /opt/Citrix/Browser-EPA/nsgcepa > nsgclient.misc 2>&1 &"
						else
							echo "suse machine"
IFS='
'
							filename=`ls /var/run/gdm | grep -i ${k[0]}`
							echo $filename
							for dd in $filename
							do
								echo "-->"
								echo $dd
								echo "<--"
								if [ -f /var/run/gdm/$dd/database ] ; then
									su - ${k[0]} -c "XAUTHLOCALHOSTNAME=localhost XAUTHORITY=/var/run/gdm/$dd/database DISPLAY=:0.0 /opt/Citrix/Browser-EPA/nsgcepa > nsgclient.misc 2>&1 &"
								fi
							done
						fi
					else
						su - ${k[0]} -c "DISPLAY=:0 /opt/Citrix/Browser-EPA/nsgcepa >> /tmp/nsgcepa.txt 2>&1"
					fi
				fi
		fi
	done

    ps -elf | grep nsgc >>  /tmp/nsgcepa.txt
unset IFS
